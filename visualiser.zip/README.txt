A visualiser for COMP3702 Assignment 1, by Dimitri Klimenko (tutor).

To run it, simply run the JAR archive (double-clicking should work).

Alternatively, you can run it from the command line with optional command-line arguments:
    java -jar visualiser.jar [problem-file] [solution-file]

For example, using the test cases provided here:
    java -jar visualiser.jar test_problem.txt test_solution.txt