"$JAVA_HOME/bin/java.exe" -jar vis.jar test_problem.txt test_solution.txt
